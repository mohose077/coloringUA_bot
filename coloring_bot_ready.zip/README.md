# Coloring Bot

Telegram bot to generate custom coloring pages for kids based on age, theme, and format.